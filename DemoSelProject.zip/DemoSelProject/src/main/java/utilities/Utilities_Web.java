package utilities;

import org.openqa.selenium.WebDriver;

public class Utilities_Web {
	WebDriver  driver=null;

	public Utilities_Web(WebDriver  driver)
	{
		this.driver=driver;
	}

	
	/*
	 * public void scrollToText(String text) { JavascriptExecutor js =
	 * (JavascriptExecutor) driver; HashMap scrollObject = new HashMap<>();
	 * scrollObject.put("predicateString", "value == '" + text + "'");
	 * scrollObject.put("direction", "down"); js.executeScript("mobile: scroll",
	 * scrollObject);
	 * 
	 * }
	 */

}
