package objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class WebLoginPage {
	
	WebDriver driver;
	
	//Concatenate driver
		public WebLoginPage(WebDriver driver)
		{
			PageFactory.initElements(driver, this);
		}
		
		@FindBy(xpath= "//div[@class='dropdown dropdown-login dropdown-tab']//a[@id='dropdownCurrency']")
		private WebElement HomePageLoginLink;
							
		
		public WebElement getHomePageLoginLink()
		{
			System.out.println("trying to click on HomePage Login Link");
			return HomePageLoginLink;
		}
		
		
		@FindBy(xpath= "//div[@class='dropdown dropdown-login dropdown-tab']//a[@id='dropdownCurrency']")
		private WebElement MyAccountDropdown;
							
		
		public WebElement getMyAccountDropdown()
		{
			System.out.println("trying to click on HomePage MyAccountDropdown");
			return MyAccountDropdown;
		}
		
		
		
		
		@FindBy(xpath= "//a[@class='dropdown-item active tr']")
		private WebElement LoginLink;
							
		
		public WebElement getLoginLink()
		{
			System.out.println("trying to click on HomePage Login Link");
			return LoginLink;
		}
		
		
		@FindBy(xpath= "//input[@placeholder='Email']")
		private WebElement UsernameInput;
							
		
		public WebElement getUsernameInput()
		{
			System.out.println("trying to enter username");
			return UsernameInput;
		}
		
		@FindBy(xpath="//input[@placeholder='Password']")
		private WebElement PasswordInput;
							
		
		public WebElement getPasswordInput()
		{
			System.out.println("trying to enter Password");
			return PasswordInput;
		}
		
		
		@FindBy(xpath="//button[@class='btn btn-primary btn-lg btn-block loginbtn']")
		private WebElement LoginBtn;
							
		
		public WebElement getLoginBtn()
		{
			System.out.println("trying to click Login Button");
			return LoginBtn;
		}
		
		
		@FindBy(name="phone")
		private WebElement MobileNumberInput;
							
		
		public WebElement getMobileNumberInput()
		{
			System.out.println("trying to MobileNumberInput");
			return MobileNumberInput;
		}
	
		
		
		@FindBy(xpath="//a[@class='dropdown-item tr']")
		private WebElement SignUpLink;
							
		
		public WebElement getSignUpLink()
		{
			System.out.println("trying to click Sign Up Link");
			return SignUpLink;
		}
		
		
		@FindBy(name="firstname")
		private WebElement FirstNameInput;
		
		
		public WebElement getFirstNameInput()
		{
			System.out.println("trying to Enter First Name Input");
			return FirstNameInput;
		}
		
		@FindBy(name="lastname")
		private WebElement LastNameInput;
							
		
		public WebElement getLastNameInput()
		{
			System.out.println("trying to Enter Last Name Input");
			return LastNameInput;
		}
		
		
		@FindBy(name="email")
		private WebElement EmailInput;
							
		
		public WebElement getEmailInput()
		{
			System.out.println("trying to Enter  Email Input");
			return EmailInput;
		}
		
		
		@FindBy(name="password")
		private WebElement PasswordInput1;
							
		
		public WebElement getPasswordInput1()
		{
			System.out.println("trying to Enter Password Input");
			return PasswordInput1;
		}
		
		
		@FindBy(name="confirmpassword")
		private WebElement ConfirmPasswordInput;
							
		
		public WebElement getConfirmPasswordInput()
		{
			System.out.println("trying to Enter Confirm Password Input");
			return ConfirmPasswordInput;
		}
		
		
		
		@FindBy(xpath="//button[@class='signupbtn btn_full btn btn-success btn-block btn-lg']")
		private WebElement SignUpBtn;
							
		
		public WebElement getSignUpBtn()
		{
			System.out.println("trying to SignUp Btn");
			return SignUpBtn;
		}
		
		
		
		
		@FindBy(xpath="//a[contains(text(),'Checkboxes')]")
		private WebElement ChecBboxLink;
							
		
		public WebElement getChecBboxLink()
		{
			System.out.println("trying to ChecBbox");
			return ChecBboxLink;
		}
		
		
		
		@FindBy(xpath="//body//input[1]")
		private WebElement chkChecBbox;
							
		
		public WebElement getchkChecBbox()
		{
			System.out.println("trying to check ChecBbox");
			return chkChecBbox;
		}
		
		

		@FindBy(xpath="//form[@id='checkboxes']")
		private WebElement chkcountCheckbox;
							
		
		public WebElement getchkcountCheckbox()
		{
			System.out.println("trying to check ChecBbox");
			return chkcountCheckbox;
		}
		
		
		
		
		
		@FindBy(xpath="//div[@class='example']//div[1]//img[1]")
		private WebElement chkMouseHover;
							
		
		public WebElement getchkMouseHover()
		{
			System.out.println("trying to check Mousehover feature");
			return chkMouseHover;
		}

}
