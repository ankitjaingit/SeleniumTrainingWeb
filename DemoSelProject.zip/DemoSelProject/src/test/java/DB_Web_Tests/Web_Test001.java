package DB_Web_Tests;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import base.base_Web;
import objectrepository.WebLoginPage;

public class Web_Test001 extends base_Web{
	@Test
	public void Web_Test001() throws IOException {

		WebDriver driver =null;
		String url = getProperties("URL"); 
		System.out.println("PLATFORM NAME: "+url);
		String browser_name = getProperties("BROWSER_NAME"); 
		/*
		 * String username = getProperties("USER_NAME"); String password =
		 * getProperties("PASSWORD");
		 */

		
		driver = getDriver(browser_name);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get(url);
		
		WebLoginPage lp = new WebLoginPage(driver);
//		lp.getHomePageLoginLink().click();
//		lp.getLoginLink().click();
//		lp.getUsernameInput().sendKeys(username);
//		lp.getPasswordInput().sendKeys(password);
//		lp.getLoginBtn().click();
//		

		
		lp.getMyAccountDropdown().click();
		lp.getSignUpLink().click();
		lp.getFirstNameInput().sendKeys("Ankit");
		lp.getLastNameInput().sendKeys("Jain");
		lp.getMobileNumberInput().sendKeys("9890959222");
		lp.getEmailInput().sendKeys("ankit@diaspark.com");
		lp.getPasswordInput1().sendKeys("password");
		lp.getConfirmPasswordInput().sendKeys("password");
		lp.getSignUpBtn().click();
		
		
		 
	}

}
